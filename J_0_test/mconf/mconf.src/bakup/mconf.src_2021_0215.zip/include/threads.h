#ifndef MC__THREADS_H
#define MC__THREADS_H

#include <vector>
#include <iostream>
#include "threadtypes.h"

#ifdef WIN32
  #include <windows.h>       // Windows threading
  #include <process.h>

  namespace MConf {

  ////typedef HANDLE  uiThread;                 // see threadtypes.h
  ////typedef HANDLE  uiMutex;                  // see threadtypes.h
  ////#define uiThreadFunc  unsigned __stdcall  // see threadtypes.h

//******************************************************************
  inline uiThread ui_beginthreadex(unsigned(__stdcall *f)(void *), void* p) {
    #ifdef _MT
      return (uiThread)_beginthreadex(NULL,0,(unsigned(__stdcall *)(void *))f, p, 0, 0);
    #else
//      #pragma message( "Singlethread application")
      f(p);
      return 0;  // single thread if th==0
    #endif
  };
  // Wait until thread terminates
  inline void ui_waitthread(uiThread thread)  {
    #ifdef _MT
      if(thread==0) return;
      WaitForSingleObject(thread, INFINITE);
      CloseHandle(thread); // Destroy the thread object
    #endif
  };
  #ifdef _MSC_VER
  #pragma warning( push )
  #pragma warning( disable : 4311  ) // warning C4311: 'Typumwandlung': Zeigerverkuerzung von 'void *' zu 'unsigned int'
  #endif
  inline void ui_endthreadex(void * retval) {
    #ifdef _MT
     _endthreadex((unsigned int)retval);
    #endif
  };
  #ifdef _MSC_VER
  #pragma warning( pop )
  #endif
//******************************************************************
  inline uiMutex ui_mutex_init() { return CreateMutex (NULL, FALSE, NULL);};
  inline int ui_mutex_lock  (uiMutex mutex) { return WaitForSingleObject(mutex,INFINITE);};
  inline int ui_mutex_unlock(uiMutex mutex) { return ReleaseMutex       (mutex); };
  inline void ui_mutex_destroy(uiMutex mutex) { CloseHandle(mutex); };

  };   //namespace MConf


#else                        // POSIX threading
  #include <pthread.h>

  namespace MConf {

  ////typedef pthread_t        uiThread;  // see threadtypes.h
  ////typedef pthread_mutex_t* uiMutex;   // see threadtypes.h
  ////#define uiThreadFunc  void *        // see threadtypes.h
//******************************************************************
  inline uiThread ui_beginthreadex(void *(*f)(void *), void* p)
  {
    uiThread th;
    //pthread_attr_t attr;
    //pthread_attr_init(&attr);
    //pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
    //int rc = pthread_create((pthread_t*)&th, &attr, f, p);
    //pthread_attr_destroy(&attr);
    int rc = pthread_create((pthread_t*)&th, NULL, f, p);
    return rc==0?th:0;  // error if th==0
  };
  // Wait until thread terminates
  inline void ui_waitthread(uiThread thread)  {
    if(thread==0) return;
    pthread_join(thread, NULL);
  };
  inline void ui_endthreadex(void *retval) { pthread_exit((void *)retval); }
//******************************************************************
  inline uiMutex ui_mutex_init()
  {
    uiMutex t=new pthread_mutex_t;
    if(t) {
      if(pthread_mutex_init(t,NULL)!=0) { delete t; t=0;}
    }
    return t;
  };
  inline int ui_mutex_lock  (uiMutex mutex) { return pthread_mutex_lock  (mutex); };
  inline int ui_mutex_unlock(uiMutex mutex) { return pthread_mutex_unlock(mutex); };
  inline void ui_mutex_destroy(uiMutex mutex)
  {
    if(mutex==0) return;
    pthread_mutex_destroy(mutex);
    delete mutex;
  }

};   //namespace MConf

#endif // WIN32

namespace MConf {

//****************************************************************************
//
// mutex is not provided; user must create it in caller routines if needed
template <class T> class Threads
{
  typedef  void(T::*TExeFun)(int i1, int i2, bool setup);
  T *obj;   
  TExeFun Exe;
  void setup__(int i1, int i2) {
    (obj->*Exe)(i1, i2,true); // call the member function of the obj
  }
  void execute__(int i1, int i2) {
    (obj->*Exe)(i1, i2,false);
  }
  struct Args {Threads *that; int i1, i2; };
  static uiThreadFunc EntryPoint(void *A)
  {
    Args *arg  =(Args*)A;
    Threads *that = arg->that;
    int i1 = arg->i1;
    int i2 = arg->i2;
    delete arg;
    that->execute__(i1, i2);
    ui_endthreadex(0);
    return 0;
  }
public:
  Threads(T *ob, TExeFun exe) : obj(ob), Exe(exe) {;}   
  virtual ~Threads() {;}
  // 
  void run(int low, int upper, int nThreads) 
  { 
    nThreads = nThreads<=0?2:nThreads;    // number of threads
#ifdef WIN32
    #ifndef _MT
    nThreads = 1;   //must be singlethread application
    #endif
#endif
    setup__(low, upper);  
    if(nThreads<=1) {
      execute__(low, upper);
      return;
    }
    int size = upper-low+1;
    int nppt = size/nThreads;         // number of points (per thread) to be handled by one thread
    nppt     = (nppt<=0)?1:nppt;
    nppt     = nThreads==1?size:nppt; 
    std::vector<uiThread> hThreads;   // to keep handles of threads
    for(int i1=low,i2=0; ;) {
      i2 = i1+nppt;
      i2 = i2>upper?upper:i2;
      Args *arg = new Args;
      arg->that = this;
      arg->i1 = i1;
      arg->i2 = i2;
      uiThread th = ui_beginthreadex(EntryPoint,(void*)arg);      
      if(th==uiThread(0)) {    // if thread is not started 
        delete arg;        
        execute__(i1, i2);
      }
      else {
        hThreads.push_back(th); 
        //std::cerr<<"Object Threads starts the thread "<<th<<":  for(i="<<i1<<";i<="<<i2<<";i++) {...}"<<std::endl<<std::flush;
      }
      i1 = i2+1;
      if(i1>upper) break;
    }
    //std::cerr<<std::endl<<std::flush;
    for(int j=0; j<(int)hThreads.size(); j++)  
      ui_waitthread(hThreads[j]);    // Wait until threads terminate
  }
};

#if 0 

// the following is the example of how to use class Threads

//****************************************************************************
// this class implements multithreading for coordinate transformation 
using MConf::Vector3d;
using std::vector;
class Mag2cyl {
  C3dMesh * mconf;
  vector<Vector3d> * cyl;
  const vector<Vector3d> * mag;
  uiMutex mutex;
  int numThreads;
public:
  Mag2cyl(C3dMesh *mc,const vector<Vector3d> *m,vector<Vector3d> *c) 
           :mconf(mc), cyl(c), mag(m) {};

  void calculate(int nThreads) {
    numThreads = nThreads;
    Threads<Mag2cyl> threads(this, &Mag2cyl::calculateEx);  
    int low = 0, upper = int(mag->size()-1);
    mutex = ui_mutex_init();
    threads.run(low, upper, nThreads); 
    ui_mutex_destroy(mutex);
  }

  void calculateEx(int low, int upper, bool setup)
  {
    if(setup) {  // setup part; it allocates arrays if needed
      int size = upper-low+1;
      cyl->resize(size);
    }
    else
    {  // exe part; it will be called from threads to fill arrays
      C3dMesh *mcf = mconf;
      if(numThreads>1) {
        mcf = new C3dMesh;
        ui_mutex_lock(mutex);  
        *mcf = *mconf;        // need a new copy of C3dMesh to be thread safe
        ui_mutex_unlock(mutex);
      }
      C3dMesh &mc = *mcf;
      
      vector<Vector3d> &cyl = *(this->cyl);
      const vector<Vector3d> &mag = *(this->mag);
      
      for(int i=low; i<=upper; i++) {
        cyl[i] = mc.mag2cyl(mag[i]);     
      }
      if(numThreads>1) delete mcf;
    }
  }

};

// in main programm

  C3dMesh mc;
  vector<Vector3d> m;
  vector<Vector3d> c;
  Mag2cyl m2c(&mc, &m, &c);
  m2c.calculate(numOfThreads);

#endif


};   //namespace MConf

#endif // MC__THREADS_H
